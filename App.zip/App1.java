import java.util.Scanner;

public class App1 {
    // Store
    static final int SIZE = 100;
    static int[] numbers = new int[SIZE];
    static int count = 0;

    static void showNumber(int result) {
        System.out.println("The result is " + result);
    }

    static void showNumber(String msg) {
        System.out.println(msg);
    }

    static void showNumber(String msg, int result) {
        System.out.println(msg + result);
    }

    static int getNumber(String msg) {
        Scanner scanner = new Scanner(System.in);
        System.out.print(msg);
        return scanner.nextInt();
    }

    static void addNumber(int number) {
        if (count < SIZE) {
            numbers[count++] = number;
        } else {
            System.out.println("List is full. Cannot add more numbers.");
        }
    }

    static void showNumber() {
        if (count == 0) {
            System.out.println("No numbers stored.");
        } else {
            for (int i = 0; i < count; i++) {
                System.out.println("Number [" + i + "]: " + numbers[i]);
            }
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int choice;

        // Input
        do {
            System.out.println("\nMenu");
            System.out.println("1. Add");
            System.out.println("2. View");
            System.out.println("3. Update");
            System.out.println("4. Delete");
            System.out.println("5. Search");
            System.out.println("6. Sort");
            System.out.println("0. Exit");
            System.out.print("Enter choice: ");
            choice = scanner.nextInt();

            // Process
            switch (choice) {
                case 1:
                    showNumber("Add");
                    int number = getNumber("Enter number: ");
                    addNumber(number);
                    break;

                case 2:
                    showNumber("View");
                    showNumber();
                    break;

                case 3:
                    System.out.println("Update");
                    System.out.print("Enter number to update: ");
                    int oldNumber = scanner.nextInt();
                    boolean updated = false;
                    for (int i = 0; i < count; i++) {
                        if (numbers[i] == oldNumber) {
                            System.out.print("Enter new number: ");
                            numbers[i] = scanner.nextInt();
                            updated = true;
                            System.out.println("Number updated.");
                            break;
                        }
                    }
                    if (!updated) {
                        System.out.println("Number not found.");
                    }
                    break;

                case 4:
                    System.out.println("Delete");
                    System.out.print("Enter number to delete: ");
                    int dNumber = scanner.nextInt();
                    boolean deleted = false;
                    for (int i = 0; i < count; i++) {
                        if (numbers[i] == dNumber) {
                            for (int j = i; j < count - 1; j++) {
                                numbers[j] = numbers[j + 1];
                            }
                            count--;
                            deleted = true;
                            System.out.println("Number deleted.");
                            break;
                        }
                    }
                    if (!deleted) {
                        System.out.println("Number not found.");
                    }
                    break;

                case 5:
                    System.out.print("Enter number to search: ");
                    int target = scanner.nextInt();
                    boolean found = false;
                    for (int i = 0; i < count; i++) {
                        if (numbers[i] == target) {
                            System.out.println("Found " + target + " at index: " + i);
                            found = true;
                            break;
                        }
                    }
                    if (!found) {
                        System.out.println(target + " not found.");
                    }
                    break;

                case 6:
                    // Bubble Sort
                    for (int i = 0; i < count - 1; i++) {
                        for (int j = 0; j < count - 1 - i; j++) {
                            if (numbers[j] > numbers[j + 1]) {
                                int temp = numbers[j];
                                numbers[j] = numbers[j + 1];
                                numbers[j + 1] = temp;
                            }
                        }
                    }
                    System.out.println("Numbers sorted.");
                    break;

                case 0:
                    System.out.println("Exiting program.");
                    return;

                default:
                    System.out.println("Invalid choice.");
            }

        } while (true);
    }
}
